package jbr.springmvc.service;

import java.util.List;

import jbr.springmvc.model.Student;

public interface StudentService {

	List<Student> ShowList();
	void deleteStudent(int id);
	void studentInsert(Student std);
}
