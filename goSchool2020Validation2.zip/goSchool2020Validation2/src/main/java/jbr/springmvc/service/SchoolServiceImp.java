package jbr.springmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jbr.springmvc.dao.SchoolDao;
import jbr.springmvc.model.School;
@Service
public class SchoolServiceImp implements SchoolService {

	@Autowired
	SchoolDao schooldao;
	
	@Override
	public void insertdetails(School school) {
		
		schooldao.insertdetails(school);
	}

}
