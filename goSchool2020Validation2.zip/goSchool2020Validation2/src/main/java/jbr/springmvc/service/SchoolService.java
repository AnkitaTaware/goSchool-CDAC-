package jbr.springmvc.service;

import java.util.List;

import jbr.springmvc.model.School;

public interface SchoolService {

	 void insertdetails(School school);
	 List<School> schoollist();
}
