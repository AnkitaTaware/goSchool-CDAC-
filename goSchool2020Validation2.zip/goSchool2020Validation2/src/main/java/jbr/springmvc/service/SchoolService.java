package jbr.springmvc.service;

import jbr.springmvc.model.School;

public interface SchoolService {

	 void insertdetails(School school);
	
}
