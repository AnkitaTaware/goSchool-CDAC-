package jbr.springmvc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class TaskController {
	
	

}
