package jbr.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jbr.springmvc.model.Student;
import jbr.springmvc.model.User;
import jbr.springmvc.model.UserRole;
import jbr.springmvc.service.StudentService;

@Controller
public class StudentlistController {

	@Autowired
	StudentService stdservice;
	public void setStdservice(StudentService stdservice) {
		this.stdservice = stdservice;
	}
	
	@RequestMapping("/showlist")
    public ModelAndView showlist() {
		
		List<Student> stdList = stdservice.ShowList();
		ModelAndView mav = new ModelAndView();
		mav.addObject("sList",stdList);
		mav.setViewName("std_list");
		return mav;
	}
	
	@RequestMapping(value="/insert",method = RequestMethod.POST)
	public String studentInsert(@ModelAttribute("std")Student std){
		
		stdservice.studentInsert(std);
		
		return "redirect:/showlist";
		}
	
	@RequestMapping(value="/insert",method = RequestMethod.GET)
	public  ModelAndView studentInsert1(@ModelAttribute("std")Student std,HttpSession session,HttpServletRequest request){

		ModelAndView mav = new ModelAndView();

		
		if(request.getSession().getAttribute("userRole")!=null) {
			System.out.println("Inside student list controller");
		mav.setViewName("insert");
		}
		return mav;
}
		
	
	
	
	public ModelAndView deleteStudent() {
		return null;
		
		
	}
		
}
