package jbr.springmvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jbr.springmvc.model.School;
import jbr.springmvc.model.Student;
import jbr.springmvc.model.User;
import jbr.springmvc.service.SchoolService;

@Controller
public class schoolController {

	@Autowired
	SchoolService schoolservice;
	
     public void setschoolController(SchoolService schoolservice)
     {
    	 this.schoolservice=schoolservice;

     }
	
     @RequestMapping(value="/insertinfo",method = RequestMethod.GET)
     ModelAndView insertdetails(School school,HttpSession session,HttpServletRequest request)
     {
  		ModelAndView mav = new ModelAndView();

    	 if(request.getSession().getAttribute("Username")!=null) {
    		 String abc=request.getSession().getAttribute("Username").toString();
    		 System.out.println("Username"+abc);
    		 System.out.println("Inside insertdetails");
 		
 		
 		//stdservice.studentInsert(std);
 		
 		mav.setViewName("schoolinfo");
    	 }
 		return mav;
    	 
     }
     
     
     @RequestMapping(value="/insertdetails",method = RequestMethod.POST)
 	public String insertschoolinfo(@ModelAttribute("school")School school,HttpSession session){
 		
    	
    	 
 		schoolservice.insertdetails(school);
 		
    	 
 		return "redirect:/insertinfo";
    	
     }   
     
     
}
