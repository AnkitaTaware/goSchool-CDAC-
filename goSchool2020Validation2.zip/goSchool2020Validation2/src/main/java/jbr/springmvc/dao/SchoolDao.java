package jbr.springmvc.dao;

import org.springframework.stereotype.Repository;

import jbr.springmvc.model.School;


public interface SchoolDao {

	void insertdetails(School school);
}
