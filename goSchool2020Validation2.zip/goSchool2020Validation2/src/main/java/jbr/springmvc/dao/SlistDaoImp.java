package jbr.springmvc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import jbr.springmvc.model.Student;

@Repository
public class SlistDaoImp implements Slistdao {

	@Autowired
	public JdbcTemplate jt;
	
	 public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	 
	 
	@Override
	public List<Student> studentList() {
		String sql = "select * from studentInformation";
		List<Student> slist = jt.query(sql,new RowMapper<Student>() {

			@Override
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				Student std = new Student();
				
				std.setFirst_name(rs.getString("firstName"));
				std.setMiddle_name(rs.getString("middleName"));
				std.setLast_name(rs.getString("LastName"));
				std.setAddress(rs.getString("Address"));
				std.setDob(rs.getString("DOB"));
				std.setGender(rs.getString("gender"));
				return std;
	
			}
			
			
			
		});
		return slist;
	}

	@Override
	public void studentInsert(Student std) {
		
		String sql="insert into studentInformation(firstName,middleName,LastName,Address,DOB,Gender) values('"+std.getFirst_name()+"','"+std.getMiddle_name()+"','"+std.getLast_name()+"','"+std.getAddress()+"','"+std.getDob()+"','"+std.getGender()+"')";
		System.out.println(sql);
		
		jt.update(sql);
		
	}


	@Override
	public void studentDelete(int id) {
		// TODO Auto-generated method stub
		
	}

}
