package jbr.springmvc.dao;



import java.util.List;


import jbr.springmvc.model.Student;


public interface Slistdao {

   public List<Student> studentList(); 
   public void studentDelete(int id);
   public void studentInsert(Student std);
}
