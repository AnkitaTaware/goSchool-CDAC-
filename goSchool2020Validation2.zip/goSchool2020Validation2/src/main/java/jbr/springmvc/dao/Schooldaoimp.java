package jbr.springmvc.dao;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jbr.springmvc.model.School;

@Repository
public class Schooldaoimp implements SchoolDao {

	@Autowired
	public JdbcTemplate jt;
	
	 public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	
	
	@Override
	public void insertdetails(School std) {
		ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpSession session = sra.getRequest().getSession();
		String uname = session.getAttribute("Username").toString();
		
		String sql="insert into schoolInformation(schooltype,schoolname,schooladdress,board,username) values('"+std.getMedium()+"','"+std.getName()+"','"+std.getAddress()+"','"+std.getBoard()+"','"+uname+"')";
		System.out.println(sql);
		
		jt.update(sql);
	}

}
