package jbr.springmvc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jbr.springmvc.model.School;
import jbr.springmvc.model.Student;

@Repository
public class Schooldaoimp implements SchoolDao {

	@Autowired
	public JdbcTemplate jt;
	
	 public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	
	
	@Override
	public void insertdetails(School std) {
		ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
		HttpSession session = sra.getRequest().getSession();
		String uname = session.getAttribute("Username").toString();
		
		String sql="insert into schoolInformation(schooltype,schoolname,schooladdress,board,username) values('"+std.getMedium()+"','"+std.getName()+"','"+std.getAddress()+"','"+std.getBoard()+"','"+uname+"')";
		System.out.println(sql);
		
		jt.update(sql);
	}


	@Override
	public List<School> showschools() {
		String sql = "select * from schoolinformation";
		List<School> slist = jt.query(sql,new RowMapper<School>() {

			@Override
			public School mapRow(ResultSet rs, int rowNum) throws SQLException {
				School std = new School();
				
				std.setMedium(rs.getString("schoolType"));
				std.setName(rs.getString("schoolName"));
				std.setAddress(rs.getString("schoolAddress"));
				std.setBoard(rs.getString("Board"));
				return std;
	 
	}

		});
	  return slist;	  
	}


	

}













