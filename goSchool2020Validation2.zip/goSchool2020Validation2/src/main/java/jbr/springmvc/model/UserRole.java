package jbr.springmvc.model;


public enum UserRole {
student,
school,
admin
}

