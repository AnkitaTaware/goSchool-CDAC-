package jbr.springmvc.model;

import java.util.Date;

import javax.annotation.Generated;


public class User {
	private String Username;
	private String emailId;
	private String password;
	private	String confirmPassword;

	private String userRole;
		
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	
	
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUsername() {
		return Username;
	}
	
	@Override
	public String toString() {
		return "User [Username=" + Username + ", emailId=" + emailId + ", password="
				+ password + ", userRole=" + userRole + "]";
	}
	public void setUsername(String username) {
		Username = username;
	}
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
}
